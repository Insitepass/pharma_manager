import 'package:flutter/material.dart';
import 'package:locum/login.dart';

class Thankyou extends StatefulWidget {
  const Thankyou({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => ThankyouState();
}

class ThankyouState extends State<Thankyou> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            iconTheme: const IconThemeData(color: Colors.black),
            centerTitle: true,
            automaticallyImplyLeading: false,
            backgroundColor: const Color.fromRGBO(37, 150, 190, 1),
            title: const Text('Registration Successful',
                style: TextStyle(color: Colors.black)),
            actions: <Widget>[
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.push(
                    context, MaterialPageRoute(builder: (context) => login())),
              )
            ]),
        body: Container(
            alignment: Alignment.center,
            child: const Text(
                'Thank you for Registering with Locum looking forward to working with you',
                style: TextStyle(
                  fontSize: 30,
                ))));
  }
}
