//import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
//import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:locum/thank_you.dart';

import 'package:multiselect_formfield/multiselect_formfield.dart';
//import 'package:file_picker/file_picker.dart';

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => RegisterState();
}

class RegisterState extends State<Register> {
  final _formKey = GlobalKey<FormState>();

  final _auth = FirebaseAuth.instance;
  String email = '';
  String password = '';
  String genderValue = 'Select Gender';
  String regSAPCvalue = 'Registerd with SAPC?';
  String designationValue = 'Select Profession';
  String qualificationsValue = 'Select Qualification';
  String locationValue = 'Preferred Location to work?';

  late TextEditingController _nameController;
  late TextEditingController _lastNameController;
  late TextEditingController _phoneNumberController;
  late TextEditingController _emailController;
  late TextEditingController _dob;
  late TextEditingController _idnumber;
  late TextEditingController _skills;
  late TextEditingController _additionalQualification;
  //late TextEditingController _availability;
  late TextEditingController _rph;

  //TODO upload documetn comes here.

  late TextEditingController _passwordController;
  late TextEditingController _cpasswordController;

  //checkbox values (array)
  final TextEditingController _registrationController = TextEditingController();

  bool proftext = false;
  bool qultext = false;

  late List _myRegistration;
  late String _myRegistrationResult;

  late List _myQualifications;
  late String _myQualificationsResulsts;

  @override
  void initState() {
    _nameController = TextEditingController();
    _lastNameController = TextEditingController();
    _phoneNumberController = TextEditingController();
    _emailController = TextEditingController();
    _dob = TextEditingController();
    _idnumber = TextEditingController();
    _skills = TextEditingController();
    _additionalQualification = TextEditingController();
    _passwordController = TextEditingController();
    //  _availability = TextEditingController();
    _rph = TextEditingController();
    _passwordController = TextEditingController();
    _cpasswordController = TextEditingController();

    _myRegistration = [];
    _myRegistrationResult = '';

    _myQualifications = [];
    _myQualificationsResulsts = '';

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            iconTheme: const IconThemeData(color: Colors.black),
            centerTitle: true,
            backgroundColor: const Color.fromRGBO(37, 150, 190, 1),
            title:
                const Text('Register', style: TextStyle(color: Colors.black))),
        body: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.all(20),
                child: Form(
                    key: _formKey,
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            child:
                                //FirstName
                                TextFormField(
                              validator: (val) {
                                if (val!.isEmpty) {
                                  return "Please fill your first name";
                                }
                                return null;
                              },
                              controller: _nameController,
                              textInputAction: TextInputAction.next,
                              decoration: const InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                border: OutlineInputBorder(),
                                labelText: 'First Name',
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            //LastName
                            child: TextFormField(
                              validator: (val) {
                                if (val!.isEmpty) {
                                  return "Please fill your Surname";
                                }
                                return null;
                              },
                              controller: _lastNameController,
                              textInputAction: TextInputAction.next,
                              decoration: const InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                border: OutlineInputBorder(),
                                labelText: 'Surname',
                              ),
                            ),
                          ),
                          Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 60, vertical: 7),
                              //Gender
                              child: DropdownButtonFormField<String>(
                                  value: genderValue,
                                  icon: const Icon(Icons.arrow_downward),
                                  iconSize: 16,
                                  elevation: 16,
                                  style: const TextStyle(
                                    color: Colors.black,
                                  ),
                                  onChanged: (String? genderValue) {
                                    setState(() {
                                      genderValue = genderValue!;
                                    });
                                  },
                                  items: <String>[
                                    'Select Gender',
                                    'Male',
                                    'Female',
                                    'Other'
                                  ].map<DropdownMenuItem<String>>(
                                      (String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                  hint: const Text('Select Gender',
                                      style: TextStyle(
                                          color: Colors.black, fontSize: 16)))),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            //Phone Number
                            child: TextFormField(
                              validator: (val) {
                                if (val!.isEmpty) {
                                  return "Please fill your Phone Number";
                                }
                                return null;
                              },
                              controller: _phoneNumberController,
                              textInputAction: TextInputAction.next,
                              decoration: const InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                border: OutlineInputBorder(),
                                labelText: 'Phone Number',
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            // Date of Birth
                            child: TextFormField(
                              validator: (val) {
                                if (val!.isEmpty) {
                                  return "Please enter your date of birth";
                                }
                                return null;
                              },
                              controller: _dob,
                              textInputAction: TextInputAction.next,
                              decoration: const InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                hintText: 'DD/MM/YYYY',
                                border: OutlineInputBorder(),
                                labelText: 'Date of Birth',
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            // ID Number
                            child: TextFormField(
                              validator: (val) {
                                if (val!.isEmpty) {
                                  return "Please fill in your ID or passport number";
                                }
                                return null;
                              },
                              controller: _idnumber,
                              textInputAction: TextInputAction.next,
                              decoration: const InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                border: OutlineInputBorder(),
                                labelText: 'Identification Number',
                              ),
                            ),
                          ),

                          //Professional Registration
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            child: MultiSelectFormField(
                              autovalidate: false,
                              chipBackGroundColor: Colors.white,
                              chipLabelStyle:
                                  const TextStyle(fontWeight: FontWeight.bold),
                              dialogTextStyle:
                                  const TextStyle(fontWeight: FontWeight.bold),
                              checkBoxActiveColor: Colors.black,
                              checkBoxCheckColor: Colors.white,
                              dialogShapeBorder: const RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(12.0))),
                              title: const Text(
                                "Professional Registration :",
                                style: TextStyle(fontSize: 16),
                              ),
                              dataSource: const [
                                {
                                  "display": "HPCSA",
                                  "value": "HPCSA",
                                },
                                {
                                  "display": "SANC",
                                  "value": "SANC",
                                },
                                {
                                  "display": "SAPC",
                                  "value": "SAPC",
                                },
                                {
                                  "display": "SAVC",
                                  "value": "SAVC",
                                },
                              ],
                              textField: 'display',
                              valueField: 'value',
                              okButtonLabel: 'OK',
                              cancelButtonLabel: 'CANCEL',
                              hintWidget: const Text(
                                  'Please choose one or more',
                                  style: TextStyle(fontSize: 12)),
                              initialValue: _myRegistration,
                              onSaved: (value) {
                                if (value == null) return;
                                setState(() {
                                  _myRegistration = value;
                                });
                              },
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            child: TextField(
                              readOnly: !qultext,
                              controller: _registrationController,
                              decoration: InputDecoration(
                                labelText: 'Other (Please Specify)',
                                prefixIcon: Checkbox(
                                  value: qultext,
                                  onChanged: (bool? value) {
                                    setState(() {
                                      qultext = value!;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            // Profession
                            child: DropdownButtonFormField<String>(
                                value: designationValue,
                                icon: const Icon(Icons.arrow_downward),
                                iconSize: 16,
                                elevation: 16,
                                style: const TextStyle(
                                  color: Colors.black,
                                ),
                                onChanged: (String? designationValue) {
                                  setState(() {
                                    designationValue = designationValue!;
                                  });
                                },
                                items: <String>[
                                  'Select Profession',
                                  'Nurse',
                                  'Specialist Registered Nurse/Midwife (SRN/M)',
                                  'Registered Nurse/Midwife (RN/M)',
                                  'Enrolled Nurse (EN)',
                                  'Enrolled Nursing Auxiliary (ENA)',
                                  'Pharmacist',
                                  'Assistant Pharmacist',
                                  'Qualified Post Basic Pharmacist Assistant',
                                  'Qualified Basic Pharmacist Assistant',
                                  'Pharmacy Technician ',
                                  'Veterinarian',
                                  'Animal Health Technician',
                                  'Laboratory Animal Technologist',
                                  'Veterinary Physiotherapist',
                                  'Veterinary Technologist',
                                  'Veterinary Nurse',
                                  'General Practitioner',
                                  'Optometrist',
                                ].map<DropdownMenuItem<String>>((String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    child: Text(value),
                                  );
                                }).toList(),
                                hint: const Text('Profession',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 16))),
                          ),

                          //Skills

                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            child: TextFormField(
                              validator: (val) {
                                if (val!.isEmpty) {
                                  return "Please fill in your skills";
                                }
                                return null;
                              },
                              controller: _skills,
                              textInputAction: TextInputAction.next,
                              decoration: const InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                hintText: 'e.g. Unisolve',
                                border: OutlineInputBorder(),
                                labelText: 'I am trained in:',
                              ),
                            ),
                          ),

                          const SizedBox(height: 20),

                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            child: MultiSelectFormField(
                              autovalidate: false,
                              chipBackGroundColor: Colors.white,
                              chipLabelStyle:
                                  const TextStyle(fontWeight: FontWeight.bold),
                              dialogTextStyle:
                                  const TextStyle(fontWeight: FontWeight.bold),
                              checkBoxActiveColor: Colors.black,
                              checkBoxCheckColor: Colors.white,
                              dialogShapeBorder: const RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(12.0))),
                              title: const Text(
                                "Select Qualification :",
                                style: TextStyle(fontSize: 16),
                              ),
                              dataSource: const [
                                {
                                  "display": "Certificate",
                                  "value": "Certificate",
                                },
                                {
                                  "display": "Diploma",
                                  "value": "Diploma",
                                },
                                {
                                  "display": "National Diploma",
                                  "value": "National Diploma",
                                },
                                {
                                  "display": "Degree",
                                  "value": "Degree",
                                },
                                {
                                  "display": "Post-Graduate",
                                  "value": "Post-Graduate",
                                },
                              ],
                              textField: 'display',
                              valueField: 'value',
                              okButtonLabel: 'OK',
                              cancelButtonLabel: 'CANCEL',
                              hintWidget: const Text(
                                  'Please choose one or more',
                                  style: TextStyle(fontSize: 12)),
                              initialValue: _myQualifications,
                              onSaved: (value) {
                                if (value == null) return;
                                setState(() {
                                  _myQualifications = value;
                                });
                              },
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            child: TextField(
                              readOnly: !proftext,
                              controller: _additionalQualification,
                              decoration: InputDecoration(
                                labelText: 'Other (Please Specify)',
                                prefixIcon: Checkbox(
                                  value: proftext,
                                  onChanged: (bool? value) {
                                    setState(() {
                                      proftext = value!;
                                    });
                                  },
                                ),
                              ),
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            //Location
                            child: DropdownButtonFormField<String>(
                                value: locationValue,
                                icon: const Icon(Icons.arrow_downward),
                                iconSize: 16,
                                elevation: 16,
                                style: const TextStyle(
                                  color: Colors.black,
                                ),
                                onChanged: (String? newValue) {
                                  setState(() {
                                    locationValue = newValue!;
                                  });
                                },
                                items: <String>[
                                  'Preferred Location to work?',
                                  'Alice',
                                  'Butterworth',
                                  'East London',
                                  'Graaff-Reinet',
                                  'Grahamstown',
                                  'King Williams Town',
                                  'Mthatha',
                                  'Port Elizabeth',
                                  'Queenstown',
                                  'Uitenhage',
                                  'Zwelitsha',
                                  'Bethlehem',
                                  'Bloemfontein',
                                  'Jagersfontein',
                                  'Kroonstad',
                                  'Odendaalsrus',
                                  'Parys',
                                  'Phuthaditjhaba',
                                  'Sasolburg',
                                  'Virginia',
                                  'Welkom',
                                  'Benoni',
                                  'Boksburg',
                                  'Brakpan',
                                  'Carletonville',
                                  'Germiston',
                                  'Johannesburg',
                                  'Krugersdorp',
                                  'Pretoria',
                                  'Randburg',
                                  'Randfontein',
                                  'Roodepoort',
                                  'Soweto',
                                  'Vanderbijlpark',
                                  'Vereeninging',
                                  'Durban',
                                  'Empangeni',
                                  'Ladysmith',
                                  'Newcastle',
                                  'Pietermaritzburg',
                                  'Pinetown',
                                  'Ulundi',
                                  'Umlazi',
                                  'Giyani',
                                  'Lebowakgomo',
                                  'Musina',
                                  'Phalaborwa',
                                  'Polokwane',
                                  'Seshego',
                                  'Sibasa',
                                  'Thabazimbi',
                                  'Emalahleni',
                                  'Nelspruit',
                                  'Secunda',
                                  'Klerksdrop',
                                  'Mahikeng',
                                  'Mmabatho',
                                  'Potchesfstroom',
                                  'Runstenburg',
                                  'Kimberly',
                                  'Kuruman',
                                  'Port Nolloth',
                                  'Bellville',
                                  'Cape Town',
                                  'Constantia',
                                  'George',
                                  'Hopefield',
                                  'Oudtshoorn',
                                  'Paarl',
                                  'Simons Town',
                                  'Stellenbosch',
                                  'Swellendam',
                                  'Worcester'
                                ].map<DropdownMenuItem<String>>((String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    child: Text(value),
                                  );
                                }).toList(),
                                hint: const Text(
                                    'Select Preferred Location to work',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 16))),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            child: TextFormField(
                              validator: (val) {
                                if (val!.isEmpty) {
                                  return "Please enter in your Rate per hour";
                                }
                                return null;
                              },
                              controller: _rph,
                              textInputAction: TextInputAction.next,
                              decoration: const InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                hintText: "R",
                                border: OutlineInputBorder(),
                                labelText: 'Rate per Hour',
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            child: TextFormField(
                              validator: (val) {
                                if (val!.isEmpty) {
                                  return "Please enter your email";
                                }
                                return null;
                              },
                              controller: _emailController,
                              textInputAction: TextInputAction.next,
                              decoration: const InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                border: OutlineInputBorder(),
                                labelText: 'Email',
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            child: TextFormField(
                              obscureText: true,
                              validator: (val) {
                                if (val!.isEmpty) {
                                  return "Please enter password";
                                }
                                return null;
                              },
                              controller: _passwordController,
                              textInputAction: TextInputAction.next,
                              decoration: const InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                border: OutlineInputBorder(),
                                labelText: 'Password',
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 60, vertical: 7),
                            child: TextFormField(
                              obscureText: true,
                              validator: (val) {
                                if (val!.isEmpty) {
                                  return "Please enter confirm Password";
                                }
                                return null;
                              },
                              controller: _cpasswordController,
                              textInputAction: TextInputAction.next,
                              decoration: const InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                border: OutlineInputBorder(),
                                labelText: 'Confirm Password',
                              ),
                            ),
                          ),
                          Container(
                              //height: 40,
                              alignment: Alignment.center,
                              padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
                              child: ElevatedButton(
                                onPressed: () async {
                                  try {
                                    if (_formKey.currentState!.validate()) {
                                      await _auth
                                          .createUserWithEmailAndPassword(
                                              email: _emailController.text,
                                              password:
                                                  _passwordController.text);
                                      if (_formKey.currentState!.validate()) {
                                        //adding data to firebase collection
                                        FirebaseFirestore.instance
                                            .collection('User Profiles')
                                            .add({
                                          'Name': _nameController.text,
                                          'lastName': _lastNameController.text,
                                          'Gender': genderValue,
                                          'Phone Number':
                                              _phoneNumberController.text,
                                          'dob': _dob.text,
                                          'ID/Passport': _idnumber.text,
                                          'Profession': designationValue,
                                          'Training': _skills.text,
                                          'ProfessionalRegistration':
                                              _myRegistration.toString(),
                                          'Additional Registration':
                                              _registrationController.text,
                                          'Qualification':
                                              _myQualifications.toString(),
                                          'Additional Qualification':
                                              _additionalQualification.text,
                                          'Preferred Location': locationValue,
                                          'Rate_per_hour': _rph.text,
                                          'Email': _emailController.text,
                                          // 'Availability': _availability.text,
                                        });

                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(const SnackBar(
                                                content: Text(
                                                    'Register Successful')));

                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    const Thankyou()));
                                      }
                                    }
                                  } on FirebaseAuthException catch (e) {
                                    showDialog(
                                        context: context,
                                        builder: (ctx) => AlertDialog(
                                            title: const Text(
                                                'Registration Failed,please try again'),
                                            content: Text('${e.message}')));
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                    primary:
                                        const Color.fromRGBO(37, 150, 190, 1),
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 30, vertical: 20),
                                    textStyle: const TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold)),
                                child: const Text('Register',
                                    style: TextStyle(color: Colors.black)),
                              ))
                        ])))));
  }
}
