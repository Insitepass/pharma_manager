import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Forgotpassword extends StatefulWidget {
  const Forgotpassword({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => ForgotpasswordState();
}

class ForgotpasswordState extends State<Forgotpassword> {
  late TextEditingController _emailController;
  final _auth = FirebaseAuth.instance;

  @override
  void initState() {
    _emailController = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            iconTheme: const IconThemeData(color: Colors.black),
            centerTitle: true,
            backgroundColor: const Color.fromRGBO(37, 150, 190, 1),
            title: const Text('Forget Password',
                style: TextStyle(color: Colors.black))),
        body: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 80, vertical: 8),
                child: Text('Please enter your email address bellow'),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 80, vertical: 8),
                child:
                    //EmailName
                    TextField(
                  controller: _emailController,
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(
                    fillColor: Colors.white,
                    filled: true,
                    border: OutlineInputBorder(),
                    labelText: 'Email',
                  ),
                ),
              ),
              Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 80, vertical: 16),
                  child: ElevatedButton(
                      child: const Text('Send Link',
                          style: TextStyle(color: Colors.black)),
                      style: ElevatedButton.styleFrom(
                          primary: const Color.fromRGBO(37, 150, 190, 1),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 30, vertical: 20),
                          textStyle: const TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                      onPressed: () async {
                        try {
                          await _auth.sendPasswordResetEmail(
                              email: _emailController.text);
                        } on FirebaseAuthException catch (e) {
                          showDialog(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                    title: const Text(
                                        "An error has occured please try again"),
                                    content: Text('${e.message}'),
                                  ));
                        }
                      }))
            ]));
  }
}
