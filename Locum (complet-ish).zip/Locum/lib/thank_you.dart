import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Thankyou extends StatefulWidget {
  const Thankyou({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => ThankyouState();
}

class ThankyouState extends State<Thankyou> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            iconTheme: const IconThemeData(color: Colors.black),
            centerTitle: true,
            backgroundColor: const Color.fromRGBO(255, 223, 0, 1),
            title: const Text('Registration Successful',
                style: TextStyle(color: Colors.black))),
        body: Container(
            alignment: Alignment.center,
            child: const Text(
                'Thank you for Registering with Locum looking forward to working with you',
                style: TextStyle(
                  fontSize: 30,
                ))));
  }
}
