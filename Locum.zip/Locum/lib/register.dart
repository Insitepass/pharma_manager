import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => RegisterState();
}

class RegisterState extends State<Register> {
  final _formKey = GlobalKey<FormState>();
  final _auth = FirebaseAuth.instance;
  String email = '';
  String password = '';


  late TextEditingController _nameController;
  late TextEditingController _emailController;
  late TextEditingController _dob;
  late TextEditingController _idnumber;
  late TextEditingController _passportnumber;
  late TextEditingController _availability;
  late TextEditingController _rph;

  //upload documetn comes here.
  late TextEditingController _passwordController;
  late TextEditingController _cpasswordController;


  @override
  void initState() {
    _nameController = TextEditingController();
    _emailController = TextEditingController();
    _dob = TextEditingController();
    _idnumber = TextEditingController();
    _passportnumber = TextEditingController();
    _passwordController = TextEditingController();
    _availability = TextEditingController();
    _rph = TextEditingController();
    _passwordController = TextEditingController();
    _cpasswordController = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            centerTitle: true,
            title: const Text('Register')
        ),
        body: SingleChildScrollView(
            child: Padding(
    padding: const EdgeInsets.all(30),
            child:Form(
           key: _formKey,
                                child: Column(
                                    crossAxisAlignment: CrossAxisAlignment
                                        .start,
                                    children: <Widget>[
                                      const SizedBox(
                                        height :15.0
                                      ),
                                      TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty) {
                                            return "Please fill your full name";
                                          }
                                          return null;
                                        },
                                        controller: _nameController,
                                        textInputAction: TextInputAction.next,
                                        decoration:  InputDecoration(
                                            fillColor: Colors.white,
                                           filled:true,
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(50.0),
                                          ),
                                          labelText: 'Full Name',
                                        ),
                                      ),
                                      const SizedBox(
                                          height :15.0
                                      ),
                                      TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty) {
                                            return "Please enter your email";
                                          }
                                          return null;
                                        },
                                        controller: _emailController,
                                        textInputAction: TextInputAction.next,
                                        decoration:  InputDecoration(
                                          fillColor: Colors.white,
                                          filled:true,
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(50.0),
                                          ),
                                          labelText: 'Email',
                                        ),
                                      ),
                                      const SizedBox(
                                          height :15.0
                                      ),
                                      TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty) {
                                            return "Please enter your date of birth";
                                          }
                                          return null;
                                        },
                                        controller: _dob,
                                        textInputAction: TextInputAction.next,
                                        decoration:  InputDecoration(
                                          fillColor: Colors.white,
                                          filled:true,
                                          hintText: 'DD/MM/YYYY',
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(50.0),
                                          ),
                                          labelText: 'Date of Birth',
                                        ),
                                      ),
                                      const SizedBox(
                                          height :15.0
                                      ),
                                      TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty) {
                                            return "Please fill in your ID or passport number";
                                          }
                                          return null;
                                        },
                                        controller: _idnumber,
                                        textInputAction: TextInputAction.next,
                                        decoration:  InputDecoration(
                                          fillColor: Colors.white,
                                          filled:true,
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(50.0),
                                          ),
                                          labelText: 'Identification Number',
                                        ),
                                      ),
                                      //Passport field
                                      // const SizedBox(
                                      //     height :15.0
                                      // ),
                                      // TextFormField(
                                      //   validator: (val) {
                                      //     if (val!.isEmpty) {
                                      //       return "Please fill in your Passport number";
                                      //     }
                                      //     return null;
                                      //   },
                                      //   controller: _passportnumber,
                                      //   textInputAction: TextInputAction.next,
                                      //   decoration:  InputDecoration(
                                      //     fillColor: Colors.white,
                                      //     filled:true,
                                      //     border: OutlineInputBorder(
                                      //       borderRadius: BorderRadius.circular(50.0),
                                      //     ),
                                      //     labelText: 'Passport Number',
                                      //   ),
                                      // ),
                                      const SizedBox(
                                          height :15.0
                                      ),
                                      TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty) {
                                            return "Please select your availability";
                                          }
                                          return null;
                                        },
                                        controller: _availability,
                                        textInputAction: TextInputAction.next,
                                        decoration:  InputDecoration(
                                          fillColor: Colors.white,
                                          filled:true,
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(50.0),
                                          ),
                                          labelText: 'Availability',
                                        ),
                                          onTap: () async{
                                          DateTime date = DateTime(1800);
                                          FocusScope.of(context).requestFocus(FocusNode());
                                          date = (await showDatePicker(
                                            context:context,
                                            initialDate: DateTime.now(),
                                            firstDate: DateTime(1800),
                                            lastDate:DateTime(2100)
                                          ))!;
                                          _availability.text = date.toIso8601String().toString();
            }
                                      ),
                                      const SizedBox(
                                          height :15.0
                                      ),
                                      TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty) {
                                            return "Please enter in your Rate per hour";
                                          }
                                          return null;
                                        },
                                        controller: _rph,
                                        textInputAction: TextInputAction.next,
                                        decoration:  InputDecoration(
                                          fillColor: Colors.white,
                                          filled:true,
                                            hintText:"R",
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(50.0),
                                          ),
                                          labelText: 'Rate per Hour',
                                        ),
                                      ),
                                      const SizedBox(
                                          height :15.0
                                      ),
                                   // uploading document
                                     Container(
                                         alignment: Alignment.center,
                                       padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
                                       child:  Ink(
                                         decoration: const ShapeDecoration(
                                           color:Colors.black,
                                           shape:CircleBorder(),
                                         ),
                                         child: IconButton(
                                           icon: const Icon(Icons.upload),
                                           iconSize:40,
                                           color: Colors.white,
                                           onPressed: () async{
                                             FilePickerResult? result = await FilePicker.platform.pickFiles();

                                             if (result != null) {
                                               Uint8List? fileBytes = result.files.first.bytes;
                                               String fileName = result.files.first.name;

                                               // Upload file
                                               await FirebaseStorage.instance.ref('Document uploads/$fileName').putData(fileBytes!);
                                             }
                                           },
                                         ) ,
                                       ),
                                     ),
                                      Container(
                                        alignment: Alignment.center,
                                        padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
                                        child: const Text('upload document',
                                        style: TextStyle(
                                          color:Colors.grey
                                        )),
                                      ),
                                      const SizedBox(
                                          height :15.0
                                      ),
                                      TextFormField(
                                        obscureText: true,
                                        validator: (val) {
                                          if (val!.isEmpty) {
                                            return "Please enter password";
                                          }
                                          return null;
                                        },
                                        controller: _passwordController,
                                        textInputAction: TextInputAction.next,
                                        decoration:  InputDecoration(
                                          fillColor: Colors.white,
                                          filled:true,
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(50.0),
                                          ),
                                          labelText: 'Password',
                                        ),
                                      ),
                                      const SizedBox(
                                          height :15.0
                                      ),
                                      TextFormField(
                                        obscureText: true,
                                        validator: (val) {
                                          if (val!.isEmpty) {
                                            return "Please enter confirm Password";
                                          }
                                          return null;
                                        },
                                        controller: _cpasswordController,
                                        textInputAction: TextInputAction.next,
                                        decoration:  InputDecoration(
                                          fillColor: Colors.white,
                                          filled:true,
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(50.0),
                                          ),
                                          labelText: 'Confirm Password',
                                        ),
                                      ),
                                      const SizedBox(
                                          height :15.0
                                      ),
                                      Container(
                                        //height: 40,
                                          alignment: Alignment.center,
                                          padding: const EdgeInsets.fromLTRB(10,10,10,0),
                                          child: ElevatedButton(

                                            onPressed:() async {
                                              try {
                                                if (_formKey.currentState!
                                                    .validate()) {
                                                  await _auth
                                                      .createUserWithEmailAndPassword(
                                                      email: _emailController
                                                          .text,
                                                      password: _passwordController
                                                          .text);
                                                  if (_formKey.currentState!
                                                      .validate()) {
                                                    //adding data to firebase collection
                                                    FirebaseFirestore.instance
                                                        .collection(
                                                        'User Profiles').add({
                                                      'FullName': _nameController
                                                          .text,
                                                      'Email': _emailController
                                                          .text,
                                                      'dob': _dob.text,
                                                      'ID/Passport': _idnumber
                                                          .text,
                                                      'Availability': _availability
                                                          .text,
                                                      'Rate_per_hour': _rph
                                                          .text,

                                                    });

                                                    ScaffoldMessenger.of(
                                                        context)
                                                        .showSnackBar(
                                                        const SnackBar(
                                                            content: Text(
                                                                'Register Successful')
                                                        )
                                                    );
                                                  }
                                                }
                                              }
                                              on FirebaseAuthException catch (e) {
                                                showDialog(
                                                    context: context,
                                                    builder: (ctx) =>
                                                        AlertDialog(
                                                            title: const Text(
                                                                'Registration Failed,please try again'),
                                                            content: Text(
                                                                '${e.message}')
                                                        )
                                                );
                                              }
                                            },
                                            style :ElevatedButton.styleFrom(
                                              //add color here
                                              textStyle:const TextStyle(
                                                  fontSize:20,
                                                  fontWeight: FontWeight.bold
                                              )
                                              ,
                                              shape:RoundedRectangleBorder(
                                                  borderRadius:BorderRadius.circular(50.0)
                                              ),
                                            ), child: const Text('Register'),
                                          )
                                      )

                                    ]
                                ),

                                       )
                        )
        )
    );
  }
}