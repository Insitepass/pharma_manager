import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:locum/forget_password.dart';
import 'package:locum/register.dart';
import 'package:locum/thank_you.dart';

class landing extends StatefulWidget {
  const landing({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => landingState();
}
//TODO fix the responsiveness of the whole thing

class landingState extends State<landing> {
  late TextEditingController _emailController;
  late TextEditingController _passwordController;
  final _auth = FirebaseAuth.instance;
  String email = '';
  String password = '';

  @override
  void initState() {
    _emailController = TextEditingController();
    _passwordController = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    //  print(size.height);
    //print(size.width);

    return Scaffold(
        body: Container(
      width: size.width,
      height: size.height,
      child: Stack(children: [
        Row(
          children: [
            Container(
              height: double.infinity,
              width: size.width / 3.3,
              color: Colors.black,
            ),
            Container(
              height: double.infinity,
              width: size.width / 2,
              // color: Colors.white,
            )
          ],
        ),

        // First Image ( Logo )
        Expanded(
          child: Container(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Image.asset('assets/logodemo.png',
                    width: 200.0, height: 200.0),
              )),
        ),

        // Second ( Tagline here)
        Expanded(
          child: Container(
              alignment: Alignment.centerLeft,
              child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Text('Tagline Here',
                          style: TextStyle(
                            color: Colors.white,
                          )),
                      const SizedBox(height: 20),
                      const Text(
                        'Paragraph here that needs to be wraped,',
                        style: TextStyle(color: Colors.white),
                      ),
                      const SizedBox(height: 30),
                      TextButton(
                        onPressed: () {},
                        child: const Text('Contact Us',
                            style: TextStyle(color: Colors.white)),
                      )
                    ],
                  ))),
        ),

        //Third Login Form
        Expanded(
          child: Container(
            padding: const EdgeInsets.only(
                top: 40.0, right: 70.0, left: 70.0, bottom: 40.0),
            child: Column(
              children: <Widget>[
                Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: const [
                      Text('Sign in to ',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 20,
                          )),
                      Text('Locum',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 30,
                          )),
                    ]),
                const SizedBox(height: 30),
                Container(
                    // color: Colors.white,
                    padding: const EdgeInsets.all(10),
                    alignment: Alignment.center,
                    child: const Text('Enter your details below')),
                const SizedBox(height: 50),
                Container(
                    /* padding: const EdgeInsets.only(
                top: 40.0, right: 70.0, left: 70.0, bottom: 40.0), */
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                      Container(
                        alignment: Alignment.center,
                        width: 300.0,
                        child: TextField(
                          controller: _emailController,
                          decoration: const InputDecoration(
                            fillColor: Colors.white,
                            filled: true,
                            icon: Icon(
                              Icons.email_outlined,
                            ),
                            border: OutlineInputBorder(),
                            /*  focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: Color.fromRGBO(255, 223, 0, 1))), */
                            labelText: 'Email',
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),
                      Container(
                          alignment: Alignment.center,
                          width: 300.0,
                          child: TextField(
                            obscureText: true,
                            controller: _passwordController,
                            decoration: const InputDecoration(
                              fillColor: Colors.white,
                              filled: true,
                              icon: Icon(
                                IconData(0xe3ae, fontFamily: 'MaterialIcons'),
                              ),
                              border: OutlineInputBorder(),
                              /* focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Color.fromRGBO(255, 223, 0, 1))), */
                              labelText: 'Password',
                            ),
                          )),
                      Container(
                          alignment: Alignment.center,
                          padding: const EdgeInsets.all(10),
                          child: TextButton(
                            child: const Text('Forgot Password ?',
                                style: TextStyle(
                                  fontSize: 15,
                                )),
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          const Forgotpassword()));
                            },
                          )),
                      const SizedBox(height: 50),
                      //login button
                      Center(
                          child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                            ElevatedButton(
                              onPressed: () async {
                                try {
                                  await _auth.signInWithEmailAndPassword(
                                      email: _emailController.text,
                                      password: _passwordController.text);

                                  // TODO route to a homepage/dashbord.
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              const Thankyou()));
                                } on FirebaseAuthException catch (e) {
                                  showDialog(
                                      context: context,
                                      builder: (ctx) => AlertDialog(
                                            title: const Text(
                                                "Login failed, please try again"),
                                            content: Text('${e.message}'),
                                          ));
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                  primary:
                                      const Color.fromRGBO(37, 150, 190, 1),
                                  padding: const EdgeInsets.all(32),
                                  textStyle: const TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                              child: const Text('Login',
                                  style: TextStyle(color: Colors.black)),
                            ),
                            const SizedBox(width: 5),
                            OutlinedButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const Register()));
                              },
                              style: OutlinedButton.styleFrom(
                                  side: const BorderSide(
                                    style: BorderStyle.solid,
                                    color: Color.fromRGBO(37, 150, 190, 1),
                                  ),
                                  padding: const EdgeInsets.all(32),
                                  textStyle: const TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                              child: const Text('Get Started'),
                            )
                          ])),
                      const SizedBox(height: 20.5),
                    ]))
              ],
            ),
          ),
        ),

        // Fourth is the contact us button
        Container(
          alignment: Alignment.bottomLeft,
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              children: const [
                Icon(
                  Icons.copyright,
                  color: Colors.white,
                  size: 24,
                ),
                SizedBox(
                  width: 8,
                ),
                Text("CopyRight 2020",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                    ))
              ],
            ),
          ),
        )
      ]),
    ));
  }
}
