import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:locum/forget_password.dart';
import 'package:locum/register.dart';
import 'package:locum/thank_you.dart';

// ignore: camel_case_types, use_key_in_widget_constructors
class login extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => loginState();
}

// ignore: camel_case_types
class loginState extends State<login> {
  late TextEditingController _emailController;
  late TextEditingController _passwordController;
  final _auth = FirebaseAuth.instance;
  String email = '';
  String password = '';

  @override
  void initState() {
    _emailController = TextEditingController();
    _passwordController = TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // appBar: AppBar(
        //   centerTitle: true,
        //   title: const Text('Login'),
        // ),
        body: Padding(
            padding: const EdgeInsets.all(20),
            child: ListView(children: <Widget>[
              Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.all(10),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: const [
                      Text('Sign in to ',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 20,
                          )),
                      Text('Locum',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 30,
                          ))
                    ]),
              ),

              Container(
                  // color: Colors.white,
                  padding: const EdgeInsets.all(10),
                  alignment: Alignment.center,
                  child: const Text('Enter your details below')),
              const SizedBox(height: 150),
              //put card here
              Column(crossAxisAlignment: CrossAxisAlignment.center, children: <
                  Widget>[
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 60, vertical: 7),
                  child: TextField(
                    controller: _emailController,
                    decoration: const InputDecoration(
                      fillColor: Colors.white,
                      filled: true,
                      icon: Icon(
                        Icons.email_outlined,
                      ),
                      border: OutlineInputBorder(),
                      /*  focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: Color.fromRGBO(255, 223, 0, 1))), */
                      labelText: 'Email',
                    ),
                  ),
                ),
                Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 60, vertical: 7),
                    child: TextField(
                      obscureText: true,
                      controller: _passwordController,
                      decoration: const InputDecoration(
                        fillColor: Colors.white,
                        filled: true,
                        icon: Icon(
                          IconData(0xe3ae, fontFamily: 'MaterialIcons'),
                        ),
                        border: OutlineInputBorder(),
                        /* focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Color.fromRGBO(255, 223, 0, 1))), */
                        labelText: 'Password',
                      ),
                    )),
                Container(
                    alignment: Alignment.topRight,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 80, vertical: 6),
                    child: TextButton(
                      child: const Text('Forgot Password ?',
                          style: TextStyle(
                            fontSize: 15,
                          )),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Forgotpassword()));
                      },
                    )),

                const SizedBox(height: 20.5),
                //login button
                Center(
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                      ElevatedButton(
                        onPressed: () async {
                          try {
                            await _auth.signInWithEmailAndPassword(
                                email: _emailController.text,
                                password: _passwordController.text);

                            // TODO route to a homepage/dashbord.
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const Thankyou()));
                          } on FirebaseAuthException catch (e) {
                            showDialog(
                                context: context,
                                builder: (ctx) => AlertDialog(
                                      title: const Text(
                                          "Login failed, please try again"),
                                      content: Text('${e.message}'),
                                    ));
                          }
                        },
                        style: ElevatedButton.styleFrom(
                            primary: const Color.fromRGBO(37, 150, 190, 1),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 30, vertical: 20),
                            textStyle: const TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold)),
                        child: const Text('Login',
                            style: TextStyle(color: Colors.black)),
                      ),
                      const SizedBox(width: 5),
                      OutlinedButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const Register()));
                        },
                        style: OutlinedButton.styleFrom(
                            side: const BorderSide(
                              style: BorderStyle.solid,
                              color: Color.fromRGBO(37, 150, 190, 1),
                            ),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 30, vertical: 20),
                            textStyle: const TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold)),
                        child: const Text('Get Started'),
                      )
                    ])),
                const SizedBox(height: 20.5),
              ])
            ])));
  }
}
